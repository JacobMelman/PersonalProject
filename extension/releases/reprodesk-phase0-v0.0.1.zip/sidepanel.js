// src/shared/state.ts
var initialState = () => ({
  mode: "inactive",
  privacy: !1,
  manual: !1,
  afk: !1,
  afkNeedsResume: !1,
  terminal: null,
  targetTabId: null,
  targetWindowId: null,
  targetOrigin: null,
  sessionId: null,
  shotSessionId: null,
  reproStartedAt: null,
  armedAt: null,
  markerCount: 0,
  afkOverride: !1
});
function collecting(s) {
  return (s.mode === "armed" || s.mode === "repro") && !s.privacy && !s.manual && !s.afk && !s.terminal;
}
function displayState(s) {
  return s.terminal === "error" ? { code: "error", label: "ERROR / NOT RECORDING", badge: "ERR" } : s.terminal === "target_ended" ? { code: "target_ended", label: "TARGET ENDED - capture stopped", badge: "END" } : s.mode === "inactive" ? { code: "inactive", label: "INACTIVE", badge: "" } : s.afk ? { code: "afk", label: "AFK - CAPTURE SUSPENDED", badge: "AFK" } : s.manual ? { code: "manual_paused", label: "PAUSED - manual", badge: "PAU" } : s.privacy ? { code: "privacy_paused", label: "PRIVACY PAUSED", badge: "PRV" } : s.mode === "screenshot_only" ? { code: "screenshot_only", label: "SCREENSHOTS ONLY / VIDEO OFF", badge: "SHOT" } : s.mode === "repro" ? { code: "recording", label: "REC", badge: "REC" } : { code: "armed", label: "ARMED", badge: "ON" };
}

// src/shared/types.ts
var DEFAULT_SETTINGS = {
  replaySec: 90,
  tailSec: 5,
  preSessionSec: 30,
  fps: 15,
  bitrateKbps: 1500,
  afkMinutes: 10,
  markerScreenshot: !0,
  captureVideo: !0,
  openReviewAfterSave: !0,
  approvedOrigins: [],
  environment: "QA"
};

// src/shared/settings.ts
async function getSettings() {
  let r = await chrome.storage.local.get("settings");
  return { ...DEFAULT_SETTINGS, ...r.settings ?? {} };
}
async function saveSettings(patch) {
  let next = { ...await getSettings(), ...patch };
  return await chrome.storage.local.set({ settings: next }), next;
}

// src/shared/filename.ts
function pad(n, w = 2) {
  return String(n).padStart(w, "0");
}
function formatClock(ms) {
  let s = Math.max(0, Math.floor(ms / 1e3));
  return `${pad(Math.floor(s / 60))}:${pad(s % 60)}`;
}

// src/storage/db.ts
var DB_NAME = "reprodesk";
var dbPromise = null;
function openDb() {
  return dbPromise || (dbPromise = new Promise((resolve, reject) => {
    let req = indexedDB.open(DB_NAME, 1);
    req.onupgradeneeded = () => {
      let db = req.result;
      db.createObjectStore("segments", { keyPath: "id" }).createIndex("endWall", "endWall"), db.createObjectStore("events", { keyPath: "id", autoIncrement: !0 }).createIndex("sessionTs", ["sessionId", "ts"]), db.createObjectStore("sessions", { keyPath: "id" }), db.createObjectStore("shots", { keyPath: "id" }).createIndex("sessionId", "sessionId"), db.createObjectStore("reports", { keyPath: "id" }).createIndex("sessionId", "sessionId"), db.createObjectStore("journal", { keyPath: "key" });
    }, req.onsuccess = () => {
      let db = req.result;
      db.onversionchange = () => {
        db.close(), dbPromise = null;
      }, resolve(db);
    }, req.onerror = () => reject(req.error);
  }), dbPromise);
}
function wrap(req) {
  return new Promise((resolve, reject) => {
    req.onsuccess = () => resolve(req.result), req.onerror = () => reject(req.error);
  });
}
async function dbGet(store, key) {
  let db = await openDb();
  return wrap(db.transaction(store).objectStore(store).get(key));
}
async function dbGetAll(store) {
  let db = await openDb();
  return wrap(db.transaction(store).objectStore(store).getAll());
}

// src/storage/opfs.ts
async function storageEstimate() {
  let est = await navigator.storage.estimate(), persisted = await navigator.storage.persisted?.() ?? !1;
  return { usageMB: (est.usage ?? 0) / 1048576, quotaMB: (est.quota ?? 0) / 1048576, persisted };
}

// src/sidepanel/index.ts
var app = document.getElementById("app"), state = initialState(), settings, health = null, notice = null, sessions = [], codecInfo = "", storageInfo = "", remembered = !1, swStarts = 0, GLYPH = {
  inactive: "\u25CB",
  armed: "\u25C9",
  recording: "\u25CF",
  screenshot_only: "\u25A3",
  privacy_paused: "\u23F8",
  manual_paused: "\u23F8",
  afk: "\u263E",
  target_ended: "\u25A0",
  error: "\u26A0"
}, cmd = (c, payload) => chrome.runtime.sendMessage({ kind: "cmd", cmd: c, payload }), esc = (s) => s.replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" })[c]);
function effectiveDisplay() {
  let d = displayState(state);
  return collecting(state) && state.mode !== "screenshot_only" && (!health || Date.now() - health.at > 6e3) && state.armedAt && Date.now() - state.armedAt > 8e3 ? { code: "error", label: "ERROR / NOT RECORDING - no capture heartbeat", badge: "ERR" } : d;
}
function render() {
  let d = effectiveDisplay(), active = state.mode !== "inactive", term = !!state.terminal, repro = state.mode === "repro", shot = state.mode === "screenshot_only", elapsed = state.reproStartedAt && !term ? formatClock(Date.now() - state.reproStartedAt) : "", o = (v, cur) => `<option value="${v}" ${String(v) === String(cur) ? "selected" : ""}>${v}</option>`, recovered = sessions.filter((s) => s.status === "recovered" && !s.reviewedAt);
  app.innerHTML = `
  <h1>ReproDesk <span class="muted small">Phase 0 spike</span></h1>
  <div class="status" data-code="${d.code}" role="status" aria-live="polite">
    <span class="glyph" aria-hidden="true">${GLYPH[d.code]}</span><span class="label">${esc(d.label)}</span><span class="timer">${elapsed}</span>
  </div>
  ${state.reason && term ? `<div class="notice error">${esc(state.reason)}</div>` : ""}
  ${active ? `<div class="muted small" style="margin-top:6px">Target: <b>${esc(state.targetOrigin ?? "?")}</b>${state.mode === "screenshot_only" ? " (video off)" : ""}</div>` : '<p class="muted">Not armed. Open the approved web app, then <b>click the ReproDesk toolbar icon</b> on that tab to arm it. Chrome only allows tab capture after that explicit user action.</p>'}
  ${notice && Date.now() - notice.at < 9e3 ? `<div class="notice ${notice.level}">${esc(notice.text)}</div>` : ""}
  ${state.afk && state.afkNeedsResume ? '<div class="notice warn">You were away. The Repro Session does not restart on its own.</div>' : ""}
  <div class="grid">
    ${term ? '<button class="wide" data-c="ackTerminal">Dismiss / re-arm later</button>' : ""}
    ${active && !term && !repro && !shot ? '<button data-c="saveReplay">Save Last Replay</button><button data-c="startRepro">Start Repro Session</button>' : ""}
    ${repro && !term ? '<button data-c="marker">Add Marker</button><button class="danger" data-c="finishRepro">Finish</button>' : ""}
    ${shot && !term ? state.sessionId ? '<button class="danger wide" data-c="finishRepro">Finish screenshot session</button>' : '<button class="wide" data-c="startRepro">Start screenshot session</button>' : ""}
    ${active && !term ? '<button data-c="screenshot" class="secondary">Screenshot</button>' : ""}
    ${active && !term && !shot ? state.manual ? '<button data-c="manualResume">Resume</button>' : '<button class="secondary" data-c="manualPause">Pause</button>' : ""}
    ${state.afk && state.afkNeedsResume ? '<button class="wide" data-c="resumeFromAfk">Resume recording</button>' : ""}
    ${active && !term && !repro && state.shotSessionId ? '<button class="secondary wide" data-c="finishShotSession">Finish screenshot collection &amp; open Review</button>' : ""}
    ${active && !repro ? '<button class="secondary wide" data-c="disarm">Disarm</button>' : ""}
  </div>
  ${active && !term && !remembered ? '<div class="row small"><span class="muted">Navigations may need host access to keep capturing.</span><button class="secondary" id="remember">Remember this site</button></div>' : ""}
  ${recovered.map((s) => `<div class="card"><b>Recovered Session</b> - recording ended unexpectedly. Last committed: ${s.lastCommittedAt ? new Date(s.lastCommittedAt).toLocaleTimeString() : "n/a"}<div class="grid"><button data-review="${s.id}">Review</button><button class="secondary" data-del="${s.id}">Delete</button></div></div>`).join("")}
  <h2>Sessions</h2>
  ${sessions.length ? sessions.slice(0, 8).map((s) => `<div class="sess"><div class="meta"><b>${esc(s.kind)} - ${esc(s.status)}</b><span class="muted small">${new Date(s.startedAt).toLocaleString()}</span></div><button class="secondary" data-review="${s.id}">Review</button><button class="secondary" data-del="${s.id}" title="Delete">\u2715</button></div>`).join("") : '<p class="muted small">No saved sessions yet.</p>'}
  <details><summary>Target Profile &amp; settings</summary>
    <label>Instant Replay window (s)</label><select data-s="replaySec">${[30, 60, 90, 120].map((v) => o(v, settings.replaySec)).join("")}</select>
    <label>Post-trigger tail (s)</label><select data-s="tailSec">${[0, 3, 5, 10].map((v) => o(v, settings.tailSec)).join("")}</select>
    <label>Pre-session context (s)</label><select data-s="preSessionSec">${[0, 30].map((v) => o(v, settings.preSessionSec)).join("")}</select>
    <label>AFK after idle (min, 0 = AFK off; locked screen is immediate)</label><select data-s="afkMinutes">${[0, 5, 10, 15, 30].map((v) => o(v, settings.afkMinutes)).join("")}</select>
    <label>Frame rate</label><select data-s="fps">${[5, 10, 15, 24, 30].map((v) => o(v, settings.fps)).join("")}</select>
    <label>Bitrate (kbps)</label><select data-s="bitrateKbps">${[600, 1e3, 1500, 2500, 4e3].map((v) => o(v, settings.bitrateKbps)).join("")}</select>
    <label>Environment</label><input type="text" data-s="environment" value="${esc(settings.environment)}">
    <label>Extra approved origins (comma separated, semantic scope)</label><input type="text" data-s="approvedOrigins" value="${esc(settings.approvedOrigins.join(", "))}" placeholder="https://auth.example.com">
    <div class="row"><span>Marker auto-screenshot</span><input type="checkbox" data-sb="markerScreenshot" ${settings.markerScreenshot ? "checked" : ""}></div>
    <div class="row"><span>Video capture (off = Screenshot-only, applies when arming)</span><input type="checkbox" data-sb="captureVideo" ${settings.captureVideo ? "checked" : ""}></div>
    <div class="row"><span>Open Review after saving</span><input type="checkbox" data-sb="openReviewAfterSave" ${settings.openReviewAfterSave ? "checked" : ""}></div>
    <p class="muted small">Shortcuts: Alt+Shift+R save replay, Alt+Shift+M marker, Alt+Shift+S screenshot. Chrome allows only 3 default keys per extension: assign "start / finish session" yourself at chrome://extensions/shortcuts.</p>
  </details>
  <details><summary>Diagnostics (Phase 0 measurements)</summary>
    <pre class="diag" id="diag">${esc(diagText())}</pre>
    <div class="row"><button class="secondary" id="copydiag">Copy diagnostics JSON</button></div>
  </details>`, bind();
}
function diagText() {
  let h = health;
  return JSON.stringify(
    {
      state: displayState(state).label,
      mode: state.mode,
      privacy: state.privacy,
      manual: state.manual,
      afk: state.afk,
      health: h ? { ...h, ageMs: Date.now() - h.at, ringBytesMB: +(h.ringBytes / 1048576).toFixed(2), writtenMB: +(h.bytesWritten / 1048576).toFixed(2), fpsEncoded: void 0 } : null,
      storage: storageInfo,
      encoders: codecInfo,
      serviceWorkerStarts: swStarts,
      chromeUA: navigator.userAgent
    },
    null,
    2
  );
}
function bind() {
  app.querySelectorAll("[data-c]").forEach((b) => b.onclick = () => {
    cmd(b.dataset.c);
  }), app.querySelectorAll("[data-review]").forEach((b) => b.onclick = () => {
    cmd("openReview", { sessionId: b.dataset.review });
  }), app.querySelectorAll("[data-del]").forEach((b) => b.onclick = async () => {
    confirm("Delete this session and its evidence from this browser?") && (await chrome.runtime.sendMessage({ kind: "delete-session", id: b.dataset.del }), await refreshSessions());
  }), app.querySelectorAll("[data-s]").forEach((el) => el.onchange = async () => {
    let k = el.dataset.s, raw = el.value, val = k === "approvedOrigins" ? raw.split(",").map((x) => x.trim()).filter(Boolean) : k === "environment" ? raw : Number(raw);
    settings = await saveSettings({ [k]: val });
  }), app.querySelectorAll("[data-sb]").forEach((el) => el.onchange = async () => {
    settings = await saveSettings({ [el.dataset.sb]: el.checked });
  });
  let rem = document.getElementById("remember");
  rem && (rem.onclick = async () => {
    if (!state.targetOrigin) return;
    await chrome.permissions.request({ origins: [`${state.targetOrigin}/*`] }) && (await cmd("siteRemembered", { origin: state.targetOrigin }), remembered = !0, render());
  });
  let cd = document.getElementById("copydiag");
  cd && (cd.onclick = () => {
    navigator.clipboard.writeText(diagText());
  });
}
async function refreshSessions() {
  sessions = (await dbGetAll("sessions")).sort((a, b) => b.createdAt - a.createdAt), render();
}
async function detectCodecs() {
  let out = [];
  for (let [name, codec] of [["VP9", "vp09.00.10.08"], ["VP8", "vp8"], ["H.264", "avc1.42001f"], ["AV1", "av01.0.04M.08"]])
    try {
      let r = await VideoEncoder.isConfigSupported({ codec, width: 1280, height: 720, bitrate: 15e5, framerate: 15 });
      out.push(`${name}:${r.supported ? "yes" : "no"}`);
    } catch {
      out.push(`${name}:err`);
    }
  codecInfo = out.join(" ");
}
async function poll() {
  health = await dbGet("journal", "health") ?? null, swStarts = (await chrome.storage.session.get("swStarts")).swStarts ?? 0;
  let est = await storageEstimate().catch(() => null);
  if (est && (storageInfo = `${est.usageMB.toFixed(1)} MB used of ${est.quotaMB.toFixed(0)} MB quota, persisted=${est.persisted}`), state.targetOrigin && (remembered = await chrome.permissions.contains({ origins: [`${state.targetOrigin}/*`] }).catch(() => !1) || remembered), !document.querySelector("details[open]")) render();
  else {
    let el = document.getElementById("diag");
    el && (el.textContent = diagText());
    let t = document.querySelector(".timer");
    t && state.reproStartedAt && (t.textContent = formatClock(Date.now() - state.reproStartedAt));
  }
}
async function main() {
  settings = await getSettings();
  let r = await chrome.storage.session.get(["state", "notice"]);
  state = r.state ?? initialState(), notice = r.notice ?? null, await detectCodecs(), await refreshSessions(), chrome.storage.session.onChanged.addListener((changes) => {
    changes.state && (state = changes.state.newValue ?? initialState()), changes.notice && (notice = changes.notice.newValue ?? null), refreshSessions();
  }), chrome.storage.onChanged.addListener((c, area) => {
    area === "local" && c.settings && (settings = { ...settings, ...c.settings.newValue });
  }), setInterval(() => {
    poll();
  }, 1e3), setInterval(() => {
    refreshSessions();
  }, 5e3);
}
main();
